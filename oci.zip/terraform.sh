#!/bin/bash
terraform init
terraform validate
terraform plan -out=/home/vipin/oci_landing_zone_plan.out
terraform show /home/vipin/oci_landing_zone_plan.out
